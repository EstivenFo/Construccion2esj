# ConstruccionDeSoftware2

## Tecnologia
Java 17 con SpringBoot 4.x.x y base de datos MySQL

## Integrantes
### Andres Felipe Sanchez Aguiar
