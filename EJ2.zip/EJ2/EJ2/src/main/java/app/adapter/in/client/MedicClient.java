package app.adapter.in.client;

public class MedicClient {
	private static final String MENU="Ingrese una opcion \n"
	+ "1. Buscar Historia clinica. \n"
	+ "2. Crear regisdto medico. \n"
	+ "3. Para actualizar registro medico. \n"
	+ "4. Para crear orden. \n";
	
	

}
