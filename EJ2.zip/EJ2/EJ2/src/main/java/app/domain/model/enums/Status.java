package app.domain.model.enums;

public enum Status {
	SCHEDULED, 
	CANCELED, 
	COMPLETED
}
